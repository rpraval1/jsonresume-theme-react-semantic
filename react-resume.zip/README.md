# jsonresume-theme-react-semantic
React and Semantic based Theme for https://jsonresume.org/schema/ open source schema
